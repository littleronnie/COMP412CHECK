from LinkedListClass import DoubleLinkedList
import sys

buffer = ''
index = 0
line_number = 0
cmdline_flag = ''
eof_flag = False
bigIR = ''
pos_array = ["MEMOP", "LOADI", "ARITHOP", "OUTPUT", "NOP", "CONSTANT", "REGISTER", "COMMA", "INTO", "ENDLINE", "NEWLINE", "ERROR"]
string_array = ["load", "store", "add", "sub", "mult", "lshift", "rshift", "output", "nop", ",", "=>", "/n", "", "loadi", "ERROR"]
error_tracker = 0

def main():
    global line_number
    global buffer
    global cmdline_flag
    global eof_flag
    global error_tracker

    args = sys.argv
    cmdline_list = parse_cmdline(args)
    filename = cmdline_list[1]
    cmdline_flag = cmdline_list[0]

    # need to change this to be what is specified
    if cmdline_flag == '-h':
        file_name = 'textfile.txt'
        with open(file_name, 'r') as file:
            text = file.read()
            print(text)
            exit(0)

    try:
        file = open(filename, 'r')
    except FileNotFoundError: print("ERROR: Could not open provided input file.")
    except IOError: print("ERROR: Could not open provided input file.")
    except Exception: print("ERROR: Could not open provided input file.")

    if cmdline_flag == '-s':
        cmdline_flag = 's'

    line_number += 1
    buffer = file.readline()
    if buffer == '':
        eof_flag = True
    parser(file)
    file.close()

    if cmdline_flag == '-p':
        if error_tracker == 0:
            print("Parse success! This succeeded!")
        else:
            print(str(error_tracker) + " lines had errors")

    if cmdline_flag == '-r':
            print(bigIR)

def parse_cmdline(args):
    valid_flags = ['-s', '-p', '-r', '-h']
    arguments = args[1:]

    if len(arguments) == 1:
        return ['-p', arguments[0]]

    file_flag = False
    flag_counter = 0
    highest_priority_flag = 0
    for cmd in arguments:
        if cmd == '-h':
            return ['-h', 'random file name']
        if cmd[0] == '-' and cmd not in valid_flags:
            print ("ERROR: Command line argument not recognized.")
            return ['-h', 'random file name']
        if cmd in valid_flags:
            flag_counter += 1
            if flag_counter == 2:
                print("ERROR:  Multiple command-line flags found. Try '-h' for information on command-line syntax.")
            if valid_flags.index(cmd) > highest_priority_flag:
                highest_priority_flag = valid_flags.index(cmd)
        if cmd not in valid_flags and file_flag == False:
            file = cmd
            file_flag = True
        if cmd not in valid_flags and file_flag == True:
            print("ERROR:  Attempt to open more than one input file.")
            return ['-h', 'random file name']
    return [valid_flags[highest_priority_flag], file]

def s():
    global buffer
    global index
    global line_number
    global error_tracker

    index += 1
    if buffer[index] == 't':
        return store()
    elif buffer[index] == 'u':
        return sub()
    else:
        print("ERROR " + str(line_number) + ": Incorrect Formatting")
        error_tracker += 1
        return (10, 14)

def sub():
    global buffer
    global index
    global line_number
    global cmdline_flag
    global pos_array
    global string_array
    global error_tracker

    index += 1
    if buffer[index] == 'b':
        index += 1
        if cmdline_flag == 's':
            print("< " + pos_array[2] + ", " + string_array[3] + " >")
        return (2, 3)
    else: 
        print("ERROR " + str(line_number) + ": Incorrect Formatting")
        error_tracker += 1
        return (10, 14)

def store():
    global buffer
    global index
    global line_number
    global cmdline_flag
    global pos_array
    global string_array
    global error_tracker

    index += 1
    if buffer[index] == 'o':
        index += 1
        if buffer[index] == 'r':
            index += 1
            if buffer[index] == 'e':
                index += 1
                if cmdline_flag == 's':
                    print("< " + pos_array[0] + ", " + string_array[1] + " >")
                return (0, 1)
    else: 
        print("ERROR " + str(line_number) + ": Incorrect Formatting")
        error_tracker += 1
        return (10, 14)

def a():
    global buffer
    global index
    global line_number
    global cmdline_flag
    global pos_array
    global string_array
    global error_tracker

    index += 1
    if buffer[index] == 'd':
        index += 1
        if buffer[index] == 'd':
            index += 1
            if cmdline_flag == 's':
                print("< " + pos_array[2] + ", " + string_array[2] + " >")
            return (2, 2)
    else: 
        print("ERROR " + str(line_number) + ": Incorrect Formatting")
        error_tracker += 1
        return (10, 14)


def n():
    global buffer
    global index
    global line_number
    global cmdline_flag
    global pos_array
    global string_array
    global error_tracker

    index += 1
    if buffer[index] == 'o':
        index += 1
        if buffer[index] == 'p':
            index += 1
            if cmdline_flag == 's':
                print("< " + pos_array[4] + ", " + string_array[8] + " >")
            return (4, 8)
    else: 
        print("ERROR " + str(line_number) + ": Incorrect Formatting")
        error_tracker += 1
        return (10, 14)


def m():
    global buffer
    global index
    global line_number
    global cmdline_flag
    global pos_array
    global string_array
    global error_tracker

    index += 1
    if buffer[index] == 'u':
        index += 1
        if buffer[index] == 'l':
            index += 1
            if buffer[index] == 't':
                index += 1
                if cmdline_flag == 's':
                    print("< " + pos_array[2] + ", " + string_array[4] + " >")
                return (2, 4)
    else: 
        print("ERROR " + str(line_number) + ": Incorrect Formatting")
        error_tracker += 1
        return (10, 14)

def o():
    global buffer
    global index
    global line_number
    global cmdline_flag
    global pos_array
    global string_array
    global error_tracker

    index += 1
    if buffer[index] == 'u':
        index += 1
        if buffer[index] == 't':
            index += 1
            if buffer[index] == 'p':
                index += 1
                if buffer[index] == 'u':
                    index += 1
                    if buffer[index] == 't':
                        index += 1
                        if cmdline_flag == 's':
                            print("< " + pos_array[3] + ", " + string_array[7] + " >")
                        return (3, 7)
    else: 
        print("ERROR " + str(line_number) + ": Incorrect Formatting")
        error_tracker += 1
        return (10, 14)


def comment(file):
    global buffer
    global index
    global line_number
    global eof_flag
    global error_tracker
    
    index += 1
    if buffer[index] == '/':
        buffer = file.readline()
        if buffer == '':
            eof_flag = True
        index = 0
        line_number += 1
        return (10, 100)
    else: 
        print("ERROR " + str(line_number) + ": Incorrect Formatting")
        error_tracker += 1
        return (10, 14)

def into():
    global buffer
    global index
    global line_number
    global cmdline_flag
    global pos_array
    global string_array
    global error_tracker

    index += 1
    if buffer[index] == '>':
        index += 1
        if cmdline_flag == 's':
            print("< " + pos_array[8] + ", " + string_array[10] + " >")
        return (8, 10)
    else: 
        print("ERROR " + str(line_number) + ": Incorrect Formatting")
        error_tracker += 1
        return (10, 14)

def r():
    global buffer
    global index
    global line_number
    global cmdline_flag
    global pos_array
    global error_tracker

    index += 1
    if buffer[index] == 's':
        return rshift()
    elif buffer[index].isnumeric():
        if int(buffer[index]) >= 0 or int(buffer[index]) <= 9:
            register_tuple = register(int(buffer[index]))
            if cmdline_flag == 's':
                print("< " + pos_array[6] + ", " + register_tuple[1] + " >")
            return register_tuple
    else: 
        print("ERROR " + str(line_number) + ": Incorrect Formatting")
        error_tracker += 1
        return (10, 14)

def rshift():
    global buffer
    global index
    global line_number
    global cmdline_flag
    global pos_array
    global string_array
    global error_tracker

    index += 1
    if buffer[index] == 's':
        index += 1
        if buffer[index] == 'h':
            index += 1
            if buffer[index] == 'i':
                index += 1
                if buffer[index] == 'f':
                    index += 1
                    if buffer[index] == 't':
                        index += 1
                        if cmdline_flag == 's':
                            print("< " + pos_array[2] + ", " + string_array[6] + " >")
                        return (2, 6)
    else: 
        print("ERROR " + str(line_number) + ": Incorrect Formatting")
        error_tracker += 1
        return (10, 14)

def register(first_numchar):
    global buffer
    global index
    tuple_string = "r" + str(first_numchar)
    numeric_flag = True
    while numeric_flag:
        index += 1
        if buffer[index].isnumeric() and int(buffer[index]) <= 9 and int(buffer[index]) >= 0:
            tuple_string += buffer[index]
        else:
            break
    return (6, tuple_string)

def constant(first_numchar):
    global buffer
    global index
    global cmdline_flag
    global pos_array
    global string_array

    tuple_string = str(first_numchar)
    numeric_flag = True
    while numeric_flag:
        index += 1
        if buffer[index].isnumeric() and int(buffer[index]) <= 9 and int(buffer[index]) >= 0:
            tuple_string += buffer[index]
        else:
            break
    if cmdline_flag == 's':
        print("< " + pos_array[5] + ", " + tuple_string[1] + " >")
    return (5, tuple_string)

def l():
    global buffer
    global index
    global error_tracker
    index += 1
    if buffer[index] == 'o':
        return lo()
    elif buffer[index] == 's':
        return lshift()
    else: 
        print("ERROR " + str(line_number) + ": Incorrect Formatting")
        error_tracker += 1
        return (10, 14)

def lshift():
    global buffer
    global index
    global line_number
    global cmdline_flag
    global pos_array
    global string_array
    global error_tracker

    index += 1
    if buffer[index] == 'h':
        index += 1
        if buffer[index] == 'i':
            index += 1
            if buffer[index] == 'f':
                index += 1
                if buffer[index] == 't':
                    index += 1
                    if cmdline_flag == 's':
                        print("< " + pos_array[2] + ", " + string_array[5] + " >")
                    return (2, 5) 
    else: 
        print("ERROR " + str(line_number) + ": Incorrect Formatting")
        error_tracker += 1
        return (10, 14)

def lo():
    global buffer
    global index
    global line_number
    global cmdline_flag
    global pos_array
    global string_array
    global error_tracker

    index += 1
    if buffer[index] == 'a':
        index += 1
        if buffer[index] == 'd':
            index += 1
            if buffer[index] == 'I':
                index += 1
                if cmdline_flag == 's':
                    print("< " + pos_array[1] + ", " + string_array[13] + " >")
                return (1, 13)
            elif buffer[index] != 'I':
                if cmdline_flag == 's':
                    print("< " + pos_array[0] + ", " + string_array[0] + " >")
                return (0, 0)
    else: 
        print("ERROR " + str(line_number) + ": Incorrect Formatting")
        error_tracker += 1
        return (10, 14)

def scanner(file_passed):
    global line_number
    global buffer
    global index
    global eof_flag
    global cmdline_flag
    global pos_array
    global string_array
    global error_tracker

    if eof_flag:
        if cmdline_flag == 's':
            print("< " + pos_array[9] + ", " + string_array[12] + " >")
        return (9, 12)
    
    first_char = buffer[index]
    while first_char == ' ' or first_char == '\t':
        index += 1
        first_char = buffer[index]

    if first_char == 's':
        return s()
    elif first_char == 'l':
        return l()
    elif first_char == 'a':
        return a()
    elif first_char == 'm':
        return m()
    elif first_char == 'n':
        return n()
    elif first_char == 'o':
        return o()
    elif first_char == '/':
        return comment(file_passed)
    elif first_char == ',':
        if cmdline_flag == 's':
            print("< " + pos_array[7] + ", " + string_array[9] + " >")
        index += 1
        return (7, 9)
    elif first_char == '=':
        return into()
    elif first_char == 'r':
        return r()
    elif first_char.isnumeric() and int(first_char) <= 9 and int(first_char) >= 0:
        return constant(int(first_char))
    elif first_char == '':
        if cmdline_flag == 's':
            print("< " + pos_array[9] + ", " + string_array[12] + " >")
        return (9, 12)
    elif first_char == '\n':
        if cmdline_flag == 's':
            print("< " + pos_array[10] + ", " + string_array[11] + " >")
        return (10, 11)
    else:
        print("ERROR " + str(line_number) + ": Incorrect Formatting at Scanner")
        error_tracker += 1
        return (10, 14)

def parser(file):
    global index
    global line_number
    global buffer
    global eof_flag

    word = scanner(file)
    while word[0] != 9:
        if word[0] == 10:
            index = 0
            line_number += 1
            buffer = file.readline()
            if buffer == '':
                eof_flag = True
        elif word[0] == 0:
            checker = finish_memop(file)
            if checker == -1:
                buffer = file.readline()
                if buffer == '':
                    eof_flag = True
                index = 0
                line_number += 1
        elif word[0] == 1:
            checker = finish_loadi(file)
            if checker == -1:
                buffer = file.readline()
                if buffer == '':
                    eof_flag = True
                index = 0
                line_number += 1
        elif word[0] == 2:
            checker = finish_arithop(file)
            if checker == -1:
                buffer = file.readline()
                if buffer == '':
                    eof_flag = True
                index = 0
                line_number += 1
        elif word[0] == 3:
            checker = finish_output(file)
            if checker == -1:
                buffer = file.readline()
                if buffer == '':
                    eof_flag = True
                index = 0
                line_number += 1
        elif word[0] == 4:
            checker = finish_nop(file)
            if checker == -1:
                buffer = file.readline()
                if buffer == '':
                    eof_flag = True
                index = 0
                line_number += 1
        word = scanner(file) 

def finish_memop(file):
    global error_tracker
    global line_number

    word = scanner(file)
    if word[0] != 6:
        print("ERROR " + str(line_number) + ": Reg incorrectly formatted")
        error_tracker += 1
        return(-1)
    else:
        word = scanner(file)
        if word[0] != 8:
            print("ERROR " + str(line_number) + ": Into is incorrectly formatted")
            error_tracker += 1
            return(-1)
        word = scanner(file)
        if word[0] != 6:
            print("ERROR " + str(line_number) + ": Reg incorrectly formatted")
            error_tracker += 1
            return(-1)
        else:
            word = scanner(file)
            if word[0] == 10:
                check_ir = "<Memop, Reg, Into, Reg, Memop> "
                add_ir(check_ir)
                return(0)
            else:
                print("ERROR " + str(line_number) + ": Last memop token incorrectly formatted")
                error_tracker += 1
                return(-1)

def finish_loadi(file):
    global error_tracker
    global line_number

    word = scanner(file)
    if word[0] != 5:
        print("ERROR " + str(line_number) + ": Constant incorrectly formatted")
        error_tracker += 1
        return(-1)
    else:
        word = scanner(file)
        if word[0] != 8:
            print("ERROR " + str(line_number) + ": Into is incorrectly formatted")
            error_tracker += 1
            return(-1)
        word = scanner(file)
        if word[0] != 6:
            print("ERROR " + str(line_number) + ": Reg incorrectly formatted")
            error_tracker += 1
            return(-1)
        else:
            word = scanner(file)
            if word[0] == 10:
                check_ir = "<Loadi, Constant, Into, Reg, Memop> "
                add_ir(check_ir)
                return(0)
            else:
                print("ERROR " + str(line_number) + ": Last memop token incorrectly formatted")
                error_tracker += 1
                return(-1)

def finish_arithop(file):
    global error_tracker
    global line_number

    word = scanner(file)
    if word[0] != 6:
        print("ERROR " + str(line_number) + ": Reg incorrectly formatted")
        error_tracker += 1
        return(-1)
    else:
        word = scanner(file)
        if word[0] != 7:
            print("ERROR " + str(line_number) + ": Comma is incorrectly formatted")
            error_tracker += 1
            return(-1)
        word = scanner(file)
        # error here
        if word[0] != 6:
            print("ERROR " + str(line_number) + ": this Reg incorrectly formatted")
            error_tracker += 1
            return(-1)
        word = scanner(file)
        if word[0] != 8:
            print("ERROR " + str(line_number) + ": Into incorrectly formatted")
            error_tracker += 1
            return(-1)
        word = scanner(file)
        if word[0] != 6:
            print("ERROR " + str(line_number) + ": Reg incorrectly formatted")
            error_tracker += 1
            return(-1)
        else:
            word = scanner(file)
            if word[0] == 10:
                check_ir = "<Arithop, Reg, Comma, Reg, Into, Reg, Memop> "
                add_ir(check_ir)
                return(0)
            else:
                print ("ERROR " + str(line_number) + ": Last memop token incorrectly formatted")
                error_tracker += 1
                return(-1)  

def finish_output(file):
    global error_tracker
    global line_number

    word = scanner(file)
    if word[0] != 5:
        print("ERROR " + str(line_number) + ": Constant incorrectly formatted")
        error_tracker += 1
        return(-1)
    else:
            word = scanner(file)
            if word[0] == 10:
                check_ir = "<Output, Constant> "
                add_ir(check_ir)
                return(0)
            else:
                print("ERROR " + str(line_number) + ": Last memop token incorrectly formatted")
                error_tracker += 1
                return(-1)

def finish_nop(file):
    global error_tracker
    global line_number

    word = scanner(file)
    if word[0] == 10:
        check_ir = "<NOP> "
        add_ir(check_ir)
        return(0)
    else:
        print("ERROR " + str(line_number) + ": Last memop token incorrectly formatted")
        error_tracker += 1
        return(-1)

def build_ir():
    littleIR = ''
    
def add_ir(inputIR):
    global bigIR
    bigIR = bigIR + inputIR

if __name__ == "__main__":
    main()
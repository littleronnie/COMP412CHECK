class DoubleLinkedList:
    def __init__(self, opcode, sr, vr, pr, nu):
        self.next = None
        self.prev = None
        self.opcode = opcode
        self.sr = sr
        self.vr = vr
        self.pr = pr
        self.nu = nu